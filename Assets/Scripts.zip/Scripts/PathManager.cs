using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PathManager : MonoBehaviour
{
    //    public static PathManager Instance { get; private set; }

    //    public List<Path> paths;

    //    public Transform checkpoint;

    //    void Awake()
    //    {
    //        if (Instance == null)
    //        {
    //            Instance = this;
    //        }
    //        else
    //        {
    //            Destroy(gameObject);
    //        }
    //    }

    //    public Path GetPath()
    //    {
    //        int i = Mathf.RoundToInt(UnityEngine.Random.Range(0, paths.Count));
    //        Path selectPath = paths[i];
    //        return selectPath;
    //    }
}
